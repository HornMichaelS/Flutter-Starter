package com.example.coffee_time

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
